<?php
$registration_no = $lab_id = $amount = $bill='';

$registration_no = $_POST['registration_no'];
$lab_id = $_POST['lab_id'];
$amount = $_POST['amount'];
//$bill = $_POST['bill'];

$bill =0;

$conn=oci_connect("putul", "12345", "localhost/XE");

if (!$conn)
{
	exit("Connection Failed: " . $conn);
}
else{
	echo "connected!";
} 



$sql = "insert into test_done values(:registration_no,:lab_id,:amount,:bill)";
$result = oci_parse($conn,$sql);
oci_bind_by_name($result, ':registration_no', $registration_no);
oci_bind_by_name($result, ':lab_id', $lab_id);
oci_bind_by_name($result, ':amount', $amount);
oci_bind_by_name($result, ':bill', $bill);
oci_execute($result);
oci_free_statement($result);

$sql1 = "update test_done td set td.bill=td.amount*(select p.price from lab p join test_done td on p.lab_id=td.lab_id and td.registration_no=:registration_no) where registration_no=:registration_no";
$result1 = oci_parse($conn,$sql1);
oci_bind_by_name($result1, ':registration_no', $registration_no);

oci_execute($result1);


?>