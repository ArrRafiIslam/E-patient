<?php
$registration_no = $date_of_admission = $room_no = $bed_no='';

$registration_no = $_POST['registration_no'];
//$dob = date('d-m-Y' strtotime($_POST['DOB']));
$date_of_admission = $_POST['date_of_admission'];
$room_no = $_POST['room_no'];
$bed_no = $_POST['bed_no'];


$conn=oci_connect("putul", "12345", "localhost/XE");

if (!$conn)
{
	exit("Connection Failed: " . $conn);
}
else{
	echo "connected!";
} 


$sql = "insert into admitted_patient values(:registration_no,:date_of_admission,:room_no,:bed_no)";

$result = oci_parse($conn,$sql);

oci_bind_by_name($result, ':registration_no', $registration_no);
oci_bind_by_name($result, ':date_of_admission', $date_of_admission);
oci_bind_by_name($result, ':room_no', $room_no);
oci_bind_by_name($result, ':bed_no', $bed_no);

oci_execute($result);

?>
