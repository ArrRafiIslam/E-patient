<html>
<head>
<title>Insert data</title>
</head>
<body>
	<form action="room_taken_insert.php" method="post">
		<table>
		<tr>
		<td>registration_no</td>
		<td><input type="text" name="registration_no"></td>
		</tr>
		<tr>
		<td>room_no</td>
		<td><input type="text" name="room_no"></td>
		</tr>
		<tr>
		<td>bed_no</td>
		<td><input type="text" name="bed_no"></td>
		</tr>
		<tr>
		<td>no_of_days</td>
		<td><input type="number_format" name="no_of_days"></td>
		</tr>
                <tr>
		<td><input type="submit" name="submit"></td>
		</tr>
		
		</table>
</form>
</body>
</html>