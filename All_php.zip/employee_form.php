<html>
<head>
<title>Insert data</title>
</head>
<body>
	<form action="insert.php" method="post">
		<table>
		<tr>
		<td>id</td>
		<td><input type="text" name="id"></td>
		</tr>
		<tr>
		<td>name</td>
		<td><input type="text" name="name"></td>
		</tr>
		<tr>
		<td>dob</td>
		<td><input type="date" name="DOB"></td>
		</tr>
		<tr>
		<td>mail</td>
		<td><input type="text" name="email"></td>
		</tr>
		<tr>
		<td>nid</td>
		<td><input type="text" name="nid"></td>
		</tr>
		<tr>
		<td>sex</td>
		<td><input type="text" name="gender"></td>
		</tr>
		<tr>
		<td>age</td>
		<td><input type="number_format" name="age"></td>
		</tr>
		<tr>
		<td>phone</td>
		<td><input type="number_format" name="phone"></td>
		</tr>
		<tr>
		<td>type</td>
		<td><input type="text" name="type"></td>
		</tr>
		<tr>
		<td><input type="submit" name="submit"></td>
		</tr>
		
		</table>
</form>
</body>
</html>