<html>
<head>
<title>Insert data</title>
</head>
<body>
	<form action="checkup_insert.php" method="post">
		<table>
		<tr>
		<td>registration_no</td>
		<td><input type="text" name="registration_no"></td>
		</tr>
    		<td>d_day</td>
		<td><input type="to_date('DD-MON-YYYY')" name="d_day"></td>
		</tr>
		<tr>
		<td>blood_pressure</td>
		<td><input type="text" name="blood_pressure"></td>
		</tr>
		<td>blood_sugar</td>
		<td><input type="text" name="blood_sugar"></td>
		</tr>
		<tr>
		<td>heart_rate</td>
		<td><input type="text" name="heart_rate"></td>
		</tr>
		<tr>
		<td>temperature</td>
		<td><input type="number_format" name="temperature"></td>
		</tr>
                <tr>
		<td><input type="submit" name="submit"></td>
		</tr>
		
		</table>
</form>
</body>
</html>