<?php
$registration_no = $name = $day = $pharmacy_bill = $lab_bill = $room_bill = $total_bill='';

$registration_no = $_POST['registration_no'];
$name = $_POST['name'];
$day = $_POST['day'];
//$pharmacy_bill = $_POST['pharmacy_bill'];
//$lab_bill = $_POST['lab_bill'];
//$room_bill = $_POST['room_bill'];
//$total_bill = $_POST['total_bill'];

$pharmacy_bill =0;
$lab_bill =0;
$room_bill =0;
$total_bill =0;

$conn=oci_connect("putul", "12345", "localhost/XE");

if (!$conn)
{
	exit("Connection Failed: " . $conn);
}
else{
	echo "connected!";
} 



$sql = "insert into transaction values(:registration_no,:name,:day,:pharmacy_bill,:lab_bill,:room_bill,:total_bill)";
$result = oci_parse($conn,$sql);
oci_bind_by_name($result, ':registration_no', $registration_no);
oci_bind_by_name($result, ':name', $name);
oci_bind_by_name($result, ':day', $day);
oci_bind_by_name($result, ':pharmacy_bill', $pharmacy_bill);
oci_bind_by_name($result, ':lab_bill', $lab_bill);
oci_bind_by_name($result, ':room_bill', $room_bill);
oci_bind_by_name($result, ':total_bill', $total_bill);
oci_execute($result);
oci_free_statement($result);

$sql1 = "update transaction t set t.pharmacy_bill=(select mt.bill from medicine_taken mt join transaction t on mt.registration_no=t.registration_no and t.registration_no=:registration_no) where registration_no=:registration_no";
$result1 = oci_parse($conn,$sql1);
oci_bind_by_name($result1, ':registration_no', $registration_no);
oci_execute($result1);
oci_free_statement($result1);

$sql2 = "update transaction t set t.room_bill=(select rt.bill from room_taken rt join transaction t on rt.registration_no=t.registration_no and t.registration_no=:registration_no) where registration_no=:registration_no";
$result2 = oci_parse($conn,$sql2);
oci_bind_by_name($result2, ':registration_no', $registration_no);
oci_execute($result2);
oci_free_statement($result2);

$sql3 = "update transaction t set t.lab_bill=(select td.bill from test_done td join transaction t on td.registration_no=t.registration_no and t.registration_no=:registration_no) where registration_no=:registration_no";	
$result3 = oci_parse($conn,$sql3);
oci_bind_by_name($result3, ':registration_no', $registration_no);
oci_execute($result3);
oci_free_statement($result3);

$sql4 = "update transaction set total_bill=(pharmacy_bill+lab_bill+room_bill) where registration_no=:registration_no";
$result4 = oci_parse($conn,$sql4);
oci_bind_by_name($result4, ':registration_no', $registration_no);
oci_execute($result4);
oci_free_statement($result4);






?>
