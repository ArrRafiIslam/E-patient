<?php
$registration_no = $room_no = $bed_no = $no_of_days = $bill='';

$registration_no = $_POST['registration_no'];
$room_no = $_POST['room_no'];
$bed_no = $_POST['bed_no'];
$no_of_days = $_POST['no_of_days'];
//$bill = $_POST['bill'];
$bill =0;

$conn=oci_connect("putul", "12345", "localhost/XE");

if (!$conn)
{
	exit("Connection Failed: " . $conn);
}
else{
	echo "connected!";
} 



$sql = "insert into room_taken values(:registration_no,:room_no,:bed_no,:no_of_days,:bill)";
$result = oci_parse($conn,$sql);
oci_bind_by_name($result, ':registration_no', $registration_no);
oci_bind_by_name($result, ':room_no', $room_no);
oci_bind_by_name($result, ':bed_no', $bed_no);
oci_bind_by_name($result, ':no_of_days', $no_of_days);
oci_bind_by_name($result, ':bill', $bill);
oci_execute($result);
oci_free_statement($result);

$sql1 = "update room_taken rt set rt.bill=rt.no_of_days*(select r.rent from room r join room_taken rt on rt.room_no=r.room_no and rt.bed_no=r.bed_no and rt.registration_no=:registration_no) where registration_no=:registration_no";
$result1 = oci_parse($conn,$sql1);

oci_bind_by_name($result1, ':registration_no', $registration_no);

oci_execute($result1);


?>
