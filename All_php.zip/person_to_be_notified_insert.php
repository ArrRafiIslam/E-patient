<?php
$registration_no = $phone = $name = $relation='';

$registration_no = $_POST['registration_no'];
$phone = $_POST['phone'];
$name = $_POST['name'];
$relation = $_POST['relation'];

$conn=oci_connect("putul", "12345", "localhost/XE");

if (!$conn)
{
	exit("Connection Failed: " . $conn);
}
else{
	echo "connected!";
} 



$sql = "insert into person_to_be_notified values(:registration_no,:phone,:name,:relation)";
$result = oci_parse($conn,$sql);
oci_bind_by_name($result, ':registration_no', $registration_no);
oci_bind_by_name($result, ':phone', $phone);
oci_bind_by_name($result, ':name', $name);
oci_bind_by_name($result, ':relation', $relation);
oci_execute($result);

?>
