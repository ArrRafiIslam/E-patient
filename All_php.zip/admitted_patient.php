<html>
<head>
<title>Insert data</title>
</head>
<body>
	<form action="admitted_patient_insert.php" method="post">
		<table>
	
		<tr>
		<td>registration_no</td>
		<td><input type="text" name="registration_no"></td>
		</tr>
		<tr>
		<td>date_of_admission</td>
		<td><input type="to_date('DD-MON-YYYY')" name="date_of_admission"></td>
		</tr>
		<tr>
		<td>room_no</td>
		<td><input type="number_format" name="room_no"></td>
		</tr>
                <tr>
		<td>bed_no</td>
		<td><input type="number_format" name="bed_no"></td>
		</tr>
		<tr>
		<tr>
		<td><input type="submit" name="submit"></td>
		</tr>
		
		</table>
</form>
</body>
</html>