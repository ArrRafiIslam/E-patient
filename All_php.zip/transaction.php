<html>
<head>
<title>Insert data</title>
</head>
<body>
	<form action="transaction_insert.php" method="post">
		<table>
		<tr>
		<td>registration_no</td>
		<td><input type="text" name="registration_no"></td>
		</tr>
		<tr>
		<td>name</td>
		<td><input type="text" name="name"></td>
		</tr>
		<tr>
                <td>day</td>
		<td><input type="to_date('DD-MON-YYYY')" name="day"></td>
		</tr>
                <tr>
		<td><input type="submit" name="submit"></td>
		</tr>
		
		</table>
</form>
</body>
</html>