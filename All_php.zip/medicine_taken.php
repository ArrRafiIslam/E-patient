<html>
<head>
<title>Insert data</title>
</head>
<body>
	<form action="medicine_taken_insert.php" method="post">
		<table>
		<tr>
		<td>registration_no</td>
		<td><input type="text" name="registration_no"></td>
		</tr>
		<tr>
		<td>medicine_id</td>
		<td><input type="text" name="medicine_id"></td>
		</tr>
		<tr>
		<td>amount</td>
		<td><input type="number_format" name="amount"></td>
		</tr>
                <tr>
		<td><input type="submit" name="submit"></td>
		</tr>
		
		</table>
</form>
</body>
</html>