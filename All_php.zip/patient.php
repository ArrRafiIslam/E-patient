<html>
<head>
<title>Insert data</title>
</head>
<body>
	<form action="patient_insert.php" method="post">
		<table>
	
		<tr>
		<td>name</td>
		<td><input type="text" name="name"></td>
		</tr>
		<tr>
		<td>dob</td>
		<td><input type="to_date('DD-MON-YYYY')" name="DOB"></td>
		</tr>
		<tr>
		<td>mail</td>
		<td><input type="text" name="mail"></td>
		</tr>
		<tr>
		<td>date_of_visit</td>
		<td><input type="to_date('DD-MON-YYYY')" name="date_of_visit"></td>
		</tr>
		<tr>
		<td>sex</td>
		<td><input type="text" name="sex"></td>
		</tr>
		<tr>
		<td>age</td>
		<td><input type="number_format" name="age"></td>
		</tr>
		<tr>
		<td>phone</td>
		<td><input type="number_format" name="phone"></td>
		</tr>
		<tr>
		<td><input type="submit" name="submit"></td>
		</tr>
		
		</table>
</form>
</body>
</html>