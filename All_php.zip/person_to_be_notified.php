<html>
<head>
<title>Insert data</title>
</head>
<body>
	<form action="person_to_be_notified_insert.php" method="post">
		<table>
                <tr>
		<td>registration_no</td>
		<td><input type="text" name="registration_no"></td>
		</tr>
                <tr>
		<td>phone</td>
		<td><input type="number_format" name="phone"></td>
		</tr>
		<tr>
		<td>name</td>
		<td><input type="text" name="name"></td>
		</tr>
		<tr>
		<td>relation</td>
		<td><input type="text" name="relation"></td>
		</tr>
		<tr>
		<td><input type="submit" name="submit"></td>
		</tr>
		
		</table>
</form>
</body>
</html>