<?php
$registration_no = $d_day = $blood_pressure = $blood_sugar = $heart_rate = $temperature='';

$registration_no = $_POST['registration_no'];
$d_day = $_POST['d_day'];
$blood_pressure = $_POST['blood_pressure'];
$blood_sugar = $_POST['blood_sugar'];
$heart_rate = $_POST['heart_rate'];
$temperature = $_POST['temperature'];


$conn=oci_connect("putul", "12345", "localhost/XE");

if (!$conn)
{
	exit("Connection Failed: " . $conn);
}
else{
	echo "connected!";
} 



$sql = "insert into checkup values(:registration_no,:d_day,:blood_pressure,:blood_sugar,:heart_rate,:temperature)";
$result = oci_parse($conn,$sql);
oci_bind_by_name($result, ':registration_no', $registration_no);
oci_bind_by_name($result, ':d_day', $d_day);
oci_bind_by_name($result, ':blood_pressure', $blood_pressure);
oci_bind_by_name($result, ':blood_sugar', $blood_sugar);
oci_bind_by_name($result, ':heart_rate', $heart_rate);
oci_bind_by_name($result, ':temperature', $temperature);
oci_execute($result);

?>