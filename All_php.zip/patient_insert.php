<?php
$name = $dob = $mail = $date_of_visit = $sex = $age = $phone='';

$name = $_POST['name'];
//$dob = date('d-m-Y' strtotime($_POST['DOB']));
$dob = $_POST['DOB'];
$mail = $_POST['mail'];
$date_of_visit = $_POST['date_of_visit'];
$sex = $_POST['sex'];
$age = $_POST['age'];
$phone = $_POST['phone'];

$conn=oci_connect("putul", "12345", "localhost/XE");

if (!$conn)
{
	exit("Connection Failed: " . $conn);
}
else{
	echo "connected!";
} 


function checkKeys($conn,$randStr){
	$keyExists = false;
	$sql = "Select * from patient";
	$result = oci_parse($conn,$sql);
	oci_execute($result);
	while(($row = oci_fetch_array($result))!= false){
		if($row['REGISTRATION_NO'] == $randStr && $row['REGISTRATION_NO'] != null){
			$keyExists = true;
			break;
		}
		else{
			$keyExists = false;
		}
	}
	return $keyExists;
}


function generateKey($conn){
	$keyLength = 12;
	//all the strings i want in id//
	$str = "0123456789";
	$randStr = substr(str_shuffle($str),0,$keyLength);
	$strval1 = "R";
	$strval2 = $strval1 . $randStr;
	$checkKey = checkKeys($conn,$strval2);
	while($checkKey == true){
		$randStr = substr(str_shuffle($str),0,$keyLength);
		$checkKey = checkKeys($conn,$randStr);
	}
	return $strval2;
}

$strval2 = generateKey($conn);



$sql = "insert into patient values(:strval2,:name,to_date('".$dob."','DD/MM/YYYY'),:mail,to_date('".$date_of_visit."','DD/MM/YYYY'),:sex,:age,:phone)";

$result = oci_parse($conn,$sql);

oci_bind_by_name($result, ':strval2', $strval2);
oci_bind_by_name($result, ':name', $name);
//oci_bind_by_name($result, ':DOB', $dob);
oci_bind_by_name($result, ':mail', $mail);
//oci_bind_by_name($result, ':date_of_visit', $date_of_visit);
oci_bind_by_name($result, ':sex', $sex);
oci_bind_by_name($result, ':age', $age);
oci_bind_by_name($result, ':phone', $phone);


oci_execute($result);

?>