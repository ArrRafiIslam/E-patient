<?php
$name = $dob = $mail = $nid = $sex = $age = $phone = $type='';

$name = $_POST['name'];
//$dob = date('d-m-Y' strtotime($_POST['DOB']));
$dob = $_POST['DOB'];
$mail = $_POST['email'];
$nid = $_POST['nid'];
$sex = $_POST['gender'];
$age = $_POST['age'];
$phone = $_POST['phone'];
$type = $_POST['type'];

$conn=oci_connect("putul", "12345", "localhost/XE");

if (!$conn)
{
	exit("Connection Failed: " . $conn);
}
else{
	echo "connected!";
} 


function checkKeys($conn,$randStr){
	$keyExists = false;
	$sql = "Select * from employee";
	$result = oci_parse($conn,$sql);
	oci_execute($result);
	while(($row = oci_fetch_array($result))!= false){
		if($row['ID'] == $randStr && $row['ID'] != null){
			$keyExists = true;
			break;
		}
		else{
			$keyExists = false;
		}
	}
	return $keyExists;
}


function generateKey($conn){
	$keyLength = 12;
	//all the strings i want in id//
	$str = "0123456789";
	$randStr = substr(str_shuffle($str),0,$keyLength);
	$strval1 = "E";
	$strval2 = $strval1 . $randStr;
	$checkKey = checkKeys($conn,$strval2);
	while($checkKey == true){
		$randStr = substr(str_shuffle($str),0,$keyLength);
		$checkKey = checkKeys($conn,$randStr);
	}
	return $strval2;
}

$strval2 = generateKey($conn);



$sql = "insert into employee values(:strval2,:name,to_date('".$dob."','DD/MM/YYYY'),:email,:nid,:gender,:age,:phone,:type)";

$result = oci_parse($conn,$sql);

oci_bind_by_name($result, ':strval2', $strval2);
oci_bind_by_name($result, ':name', $name);
oci_bind_by_name($result, ':email', $mail);
oci_bind_by_name($result, ':nid', $nid);
oci_bind_by_name($result, ':gender', $sex);
oci_bind_by_name($result, ':age', $age);
oci_bind_by_name($result, ':phone', $phone);
oci_bind_by_name($result, ':type', $type);

oci_execute($result);

?>
