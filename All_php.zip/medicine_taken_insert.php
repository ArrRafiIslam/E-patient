<?php
$registration_no = $medicine_id = $amount = $bill='';

$registration_no = $_POST['registration_no'];
$medicine_id = $_POST['medicine_id'];
$amount = $_POST['amount'];
//$bill = $_POST['bill'];

$bill =0;

$conn=oci_connect("putul", "12345", "localhost/XE");

if (!$conn)
{
	exit("Connection Failed: " . $conn);
}
else{
	echo "connected!";
} 



$sql = "insert into medicine_taken values(:registration_no,:medicine_id,:amount,:bill)";
$result = oci_parse($conn,$sql);
oci_bind_by_name($result, ':registration_no', $registration_no);
oci_bind_by_name($result, ':medicine_id', $medicine_id);
oci_bind_by_name($result, ':amount', $amount);
oci_bind_by_name($result, ':bill', $bill);
oci_execute($result);
oci_free_statement($result);

$sql1 = "update medicine_taken mt set mt.bill=mt.amount*(select p.price from pharmacy p join medicine_taken mt on p.medicine_id=mt.medicine_id and mt.registration_no=:registration_no) where registration_no=:registration_no";
$result1 = oci_parse($conn,$sql1);
oci_bind_by_name($result1, ':registration_no', $registration_no);

oci_execute($result1);


?>
